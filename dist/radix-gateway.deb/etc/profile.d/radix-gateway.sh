FOPIS_PATH=/opt/fopis
export FOPIS_PATH="$FOPIS_PATH"
export PATH="$PATH:/opt/fopis/bin"
